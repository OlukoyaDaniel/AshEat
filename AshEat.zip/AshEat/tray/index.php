<?php include('../inc/login_head.php');?>
<strong><h5>Your tray</h5></strong>
<br>
<div class="">
  <div>
    <p>Fried Rice</p>
    <sub class="sub">Quantity: <span class="red-text mr-5">1</span> Portion: <span class="red-text mr-5">Full Portion</span> <span class="red-text mr-5">Take Away</span> <span class="red-text">Ghc 10.00</span></sub>
  </div>
  <hr>
  <div>
    <p>Water</p>
    <sub class="sub">Quantity: <span class="red-text mr-5">1</span><span class="red-text">Ghc 1.20</span></sub>
  </div>
  <hr>
</div>

<p>Total <br><span class="red-text">Ghc 11.20</span></p>

<form action="">
<div class="form-group">
    <label for="mealplan">Are you on a meal plan card?</label>
    <select class="form-control" id="mealplan">
      <option>Select a payment option...</option>
      <option>Cash</option>
      <option>Meal plan</option>
    </select>
  </div>
  <div class="form-group">
    <label for="fullname"><strong>For card usage enter pin</strong></label>
    <input type="text" class="form-control" id="fullname" placeholder="Enter pin for you meal plan">
  </div>
  <br>
  <button type="submit" class="btn category btn-block btn-lg ">ADD TO TRAY</button>
</form>


<?php include('../inc/footer.php');?>