<?php

$msg = '';
$msgClass = '';
$mealplan='';
if(isset($_POST["submit"])) {
  $id = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['id']) ? $_POST['id'] : ''));
  $password = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['password']) ? $_POST['password'] : ''));

  if (empty($name)) {
    $msg = 'Please enter full name.';
    $msgClass = 'alert-danger';
  } else if (empty($password)) {
    $msg = 'Please enter a password.';
    $msgClass = 'alert-danger';
  }
  else{
    $query="";
      if (mysqli_query($conn, $query)) {
        $msg = 'Update Successful';
        $msgClass = 'alert-success';
        header('Location:' . ROOT_URL . 'edit.php');
      } else {
        $msg = 'ERROR:' . mysqli_error($conn);
        $msgClass = 'alert-danger';
      }
  }

}
?>

<?php include('inc/normal_head.php');?>
<h5 class="font-weight-bold">Login</h5>
<div class="container">
<br>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <?php if ($msg != '') : ?>
  <div class="alert my-5 <?php echo "$msgClass"; ?>">
      <?php echo "$msg"; ?>
  </div>
  <?php endif ?>
  <div class="form-group">
    <label for="id_number">ID Number</label>
    <input type="text" name="id" class="form-control" id="id_number" placeholder="Enter ID number">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" name="password" class="form-control" id="password" placeholder="Please enter password">
  </div>
  <br>
  <button type="submit" name="submit" class="btn category btn-block btn-lg">Login</button>
</form>
<br>
<div class="text-center">
  <a href="<?php echo ROOT_URL?>signup"><p class="text-dark">Don't have an account? <span class="text-danger">Sign Up</span></p></a>
</div>
</div>
<?php include('inc/footer.php');?>