<?php include('../../inc/login_head.php');?>
<ul class="nav nav-pills nav-fill">
  <li class="nav-item">
    <a class="nav-link text-dark" href="/bigben">Foods</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-dark" href="/bigben/drinks">Drinks</a>
  </li>
  <li class="nav-item">
    <a class="nav-link category" href="/bigben/pastries">Pastries</a>
  </li>
</ul>

<br>
<br>

<div class="px-5">
  <!-- Button trigger modal -->
  <a class="btn btn-block btn-lg" data-toggle="modal" data-target="#food_modal">
    <div style="float:left">
      Meat Pie
    </div>
    <div style="float:right" class="price">
      Ghc 10.00
    </div>
    <div class="clear"></div>
  </a>
  <!-- Modal -->
  <div class="modal fade" id="food_modal" tabindex="-1" role="dialog" aria-labelledby="contactTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5>Add <span class="red-text">Meat Pie</span> to tray?</h5>
          <hr>
        </div>
        <div class="modal-body" style="background:#F7F7F7; text-align: left;padding: 3vh;">
          <form>
            <div class="form-group">
              <label for="quantity" class="col-form-label">Enter a Quantity</label>
              <input type="number" class="form-control" id="quantity">
            </div>
            <div class="modal-footer" style="background:#F7F7F7;">
              <button type="button" class="btn btn-lg btn-block category" style="border-radius: 5px">ADD TO TRAY</button>
            </div>
          </form>
        </div>
        
      </div>
    </div>
  </div>
  <hr>
</div>




<?php include('../../inc/footer.php');?>