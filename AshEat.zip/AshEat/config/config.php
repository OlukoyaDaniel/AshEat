<?php
  define('ROOT_URL','http://localhost/asheat/');
  define('DB_HOST','localhost');
  define('DB_USER','root');
  define('DB_PASS','');
  define('DB_NAME','asheat');
  define('ADMIN_NAME','');
  define('ADMIN_PASS','');