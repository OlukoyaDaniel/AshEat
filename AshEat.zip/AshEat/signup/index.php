<?php

$msg = '';
$msgClass = '';
$mealplan='';
if(isset($_POST["submit"])) {
  $name = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['name']) ? $_POST['name'] : ''));
  $id = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['id']) ? $_POST['id'] : ''));
  $email = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['email']) ? $_POST['email'] : ''));
  $password = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['password']) ? $_POST['password'] : ''));
  $cpassword = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['cpassword']) ? $_POST['cpassword'] : ''));
  $mealplan = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['mealplan']) ? $_POST['mealplan'] : ''));
  $pin = mysqli_real_escape_string($conn, htmlspecialchars(isset($_POST['pin']) ? $_POST['pin'] : ''));
  
  if (empty($name)) {
    $msg = 'Please enter full name.';
    $msgClass = 'alert-danger';
  } else if (empty($id)) {
    $msg = 'Please enter id.';
    $msgClass = 'alert-danger';
  }
  else if (empty($email)) {
    $msg = 'Please enter your email address.';
    $msgClass = 'alert-danger';
  }
  else if (empty($password)) {
    $msg = 'Please enter password.';
    $msgClass = 'alert-danger';
  }
  else if (empty($cpassword)) {
    $msg = 'Please enter password confirmation.';
    $msgClass = 'alert-danger';
  }
  else if ($cpassword!=$password) {
    $msg = "Passwords don't match.";
    $msgClass = 'alert-danger';
  }
  else if ($mealplan=="Select an option...") {
    $msg = 'Please specify if your are on a mealplan.';
    $msgClass = 'alert-danger';
  }
  else if ($mealplan=="Yes" && empty($pin)) {
    $msg = 'Please enter mealplan pin.';
    $msgClass = 'alert-danger';
  }
  else{
    $query="Insert into User(full_name, id, email, password, meal_plan, pin) values ('$name', '$id', '$email', '$password', '$mealplan', '$pin');";
      if (mysqli_query($conn, $query)) {
        $msg = 'Sign up successful, you can proceed to login';
        $msgClass = 'alert-success';
      } else {
        $msg = 'ERROR:' . mysqli_error($conn);
        $msgClass = 'alert-danger';
      }
  }

}
?>

<?php include('../inc/normal_head.php');?>
<h5 class="font-weight-bold">Sign Up</h5>
<div class="container">
<br>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <?php if ($msg != '') : ?>
  <div class="alert my-5 <?php echo "$msgClass"; ?>">
      <?php echo "$msg"; ?>
  </div>
  <?php endif ?>
  <div class="form-group">
    <label for="fullname">Full Name</label>
    <input type="text" name="name" class="form-control" id="fullname" placeholder="Enter your full name">
  </div>
  <div class="form-group">
    <label for="id_number">ID Number</label>
    <input type="text" name="id" class="form-control" id="id_number" placeholder="Enter your ID number">
  </div>
  <div class="form-group">
    <label for="email">Ashesi Email Address</label>
    <input type="email" name="email" class="form-control" id="email" placeholder="Enter your Ashesi Email address">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" name="password" class="form-control" id="password" placeholder="Please enter password">
  </div>
  <div class="form-group">
    <label for="cpassword">Confirm Password</label>
    <input type="password" name="cpassword" class="form-control" id="cpassword" placeholder="Please re-enter password">
  </div>
  <div class="form-group">
    <label for="mealplan">Are you on a meal plan card?</label>
    <select class="form-control" id="mealplan" name="mealplan">
      <option <?php if ($mealplan == '' || $mealplan == 'Select an option...') echo 'selected'; ?>>Select an option...</option>
      <option <?php if ($mealplan == 'yes') echo 'selected'; ?>>Yes</option>
      <option <?php if ($mealplan == 'no') echo 'selected'; ?>>No</option>
    </select>
  </div>
  <div class="form-group">
    <label for="fullname"><strong>If yes to the above please enter a pin for card usage</strong></label>
    <input type="text" name="pin" class="form-control" id="fullname" placeholder="Enter pin for you meal plan">
  </div>
  <br>
  <button type="submit" name="submit" class="btn category btn-block btn-lg">Sign Up</button>
</form>
<br>
<div class="text-center">
  <a href="<?php echo ROOT_URL?>"><p class="text-dark">Already have an account? <span class="text-danger">Login</span></p></a>
</div>

</div>


<?php include('../inc/footer.php');?>