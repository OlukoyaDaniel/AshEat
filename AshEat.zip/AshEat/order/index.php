<?php include('../inc/login_head.php');?>
<strong><h5>Your orders</h5></strong>
<br>
<div class="">
  <a class="btn btn-block btn-lg" data-toggle="modal" data-target="#food_modal">
  <div>
    <div style="float:left"><p>Order 1005</p></div>
    <div style="float:right"><sub>12/05/2018 <br> 12:00pm</sub></div>
    <div class="clear"></div>
  </div>
  </a>

  <div class="modal fade" id="food_modal" tabindex="-1" role="dialog" aria-labelledby="contactTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5>Order 1005 details</h5>
          <hr>
        </div>
        <div class="modal-body" style="background:#F7F7F7; text-align: left;padding: 3vh;">
        <div>
          <p>Fried Rice</p>
          <sub class="sub">Quantity: <span class="red-text mr-5">1</span> Portion: <span class="red-text mr-5">Full Portion</span> <span class="red-text mr-5">Take Away</span></sub>
        </div>
        <hr>
        <div>
          <p>Water</p>
          <sub class="sub">Quantity: <span class="red-text mr-5">1</span></sub>
        </div>
        <br>
        <div>
          <div style="float:left">
            <p>Total: <br><span class="red-text">Ghc 11.20</span></p>
          </div>
          <div style="float:right">
            <p>Paid with: <br><span class="red-text">Meal Plan</span></p>
          </div>
        </div>
        <div class="clear"></div>
        <hr>
        <p class="text-success text-center">Your order is ready for pick up</p>
        </div>
        
      </div>
    </div>
  </div>
  <hr>
  
  
</div>




<?php include('../inc/footer.php');?>