<?php include('../../inc/normal_head.php');?>
<ul class="nav nav-pills nav-fill">
  <li class="nav-item">
    <a class="nav-link text-dark" href="/g_bigben">Foods</a>
  </li>
  <li class="nav-item">
    <a class="nav-link category" href="/g_bigben/drinks">Drinks</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-dark" href="/g_bigben/pastries">Pastries</a>
  </li>
</ul>

<br>
<br>

<div class="container px-5">
  <div style="float:left">
    Don Simon
  </div>
  <div style="float:right" class="price">
    Ghc 10.00
  </div>
  <div class="clear"></div>
  <hr>
</div>




<?php include('../../inc/footer.php');?>